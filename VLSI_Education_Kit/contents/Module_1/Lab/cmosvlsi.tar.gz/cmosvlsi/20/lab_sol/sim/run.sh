sim-nc processor_multi.sv -f verilog.inpfiles
