find . -name "*.cdslck" -type f -delete
