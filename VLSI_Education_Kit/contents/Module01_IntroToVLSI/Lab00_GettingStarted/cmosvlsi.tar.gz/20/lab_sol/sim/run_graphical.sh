sim-ncg arm_multi.sv -f verilog.inpfiles
